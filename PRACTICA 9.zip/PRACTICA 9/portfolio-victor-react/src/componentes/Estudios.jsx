import { useState } from 'react';

function Estudios({ estudios, añadirEstudio, borrarEstudio }) {
    const [titulo, setTitulo] = useState('');
    const [centro, setCentro] = useState('');
    const [periodo, setPeriodo] = useState('');

    function enviarFormulario(event) {
        event.preventDefault();

        const nuevoEstudio = {
            titulo: titulo,
            centro: centro,
            periodo: periodo,
            fijo: false
        };

        añadirEstudio(nuevoEstudio);
        setTitulo('');
        setCentro('');
        setPeriodo('');
    }

    return (
        <section id="estudios">
            <h2>Estudios</h2>

            {estudios.map(function (estudio, index) {
                return (
                    <article className="tarjeta" key={index}>
                        <h3>{estudio.titulo}</h3>
                        <p><strong>Centro:</strong> {estudio.centro}</p>
                        <p><strong>Período:</strong> {estudio.periodo}</p>
                        {!estudio.fijo && <button className="borrar" onClick={() => borrarEstudio(index)}>Borrar</button>}
                    </article>
                );
            })}

            <br />
            <h3>Añadir estudio</h3>
            <form className="formulario" onSubmit={enviarFormulario}>
                <label htmlFor="titulo">Título</label>
                <input type="text" id="titulo" placeholder="Nombre del estudio" value={titulo} onChange={(e) => setTitulo(e.target.value)} required />

                <label htmlFor="centro">Centro</label>
                <input type="text" id="centro" placeholder="Nombre del centro" value={centro} onChange={(e) => setCentro(e.target.value)} required />

                <label htmlFor="periodo">Período</label>
                <input type="text" id="periodo" placeholder="Ej: 2023 - 2025" value={periodo} onChange={(e) => setPeriodo(e.target.value)} required />

                <button type="submit">Añadir</button>
            </form>
        </section>
    );
}

export default Estudios;
