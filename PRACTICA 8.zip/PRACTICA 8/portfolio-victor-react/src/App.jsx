import { useState } from 'react';
import Cabecera from './componentes/Cabecera.jsx';
import Menu from './componentes/Menu.jsx';
import SobreMi from './componentes/SobreMi.jsx';
import Estudios from './componentes/Estudios.jsx';
import Experiencia from './componentes/Experiencia.jsx';
import Habilidades from './componentes/Habilidades.jsx';
import Proyectos from './componentes/Proyectos.jsx';
import Contacto from './componentes/Contacto.jsx';
import Pie from './componentes/Pie.jsx';

function App() {
    const [oscuro, setOscuro] = useState(false);

    const estudios = [
        {
            titulo: 'Grado Superior DAM – Desarrollo de Aplicaciones Multiplataforma',
            centro: 'IES Modesto Navarro, La Solana',
            periodo: 'Septiembre 2025 – actualidad'
        },
        {
            titulo: 'Grado Medio SMR – Sistemas Microinformáticos y Redes',
            centro: 'IES Modesto Navarro, La Solana',
            periodo: 'Septiembre 2023 – Junio 2025'
        }
    ];

    const habilidades = ['Java', 'HTML y CSS', 'Bases de datos', 'Git / GitHub', 'Sistemas informáticos'];

    const proyectos = [
        {
            titulo: 'Portfolio personal',
            descripcion: 'Página web personal creada con HTML y CSS durante las prácticas de FP Dual.'
        },
        {
            titulo: 'App de gestión de tareas',
            descripcion: 'Aplicación de escritorio en Java para organizar tareas del día a día.'
        },
        {
            titulo: 'Base de datos de una biblioteca',
            descripcion: 'Diseño y creación de una base de datos relacional para gestionar libros y préstamos.'
        }
    ];

    function cambiarTema() {
        setOscuro(!oscuro);
    }

    return (
        <div className={oscuro ? 'pagina oscuro' : 'pagina'}>
            <Cabecera oscuro={oscuro} cambiarTema={cambiarTema} />
            <Menu />
            <main className="contenido">
                <SobreMi />
                <hr />
                <Estudios estudios={estudios} />
                <hr />
                <Experiencia />
                <hr />
                <Habilidades habilidades={habilidades} />
                <hr />
                <Proyectos proyectos={proyectos} />
                <hr />
                <Contacto />
            </main>
            <Pie />
        </div>
    );
}

export default App;
