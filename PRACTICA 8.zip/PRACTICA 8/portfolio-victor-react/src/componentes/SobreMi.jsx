function SobreMi() {
    return (
        <section id="sobre-mi">
            <h2>Sobre mí</h2>
            <p>
                Me llamo Víctor, tengo 18 años y soy estudiante de primer curso de DAM
                (Desarrollo de Aplicaciones Multiplataforma) en FP Dual.
                Anteriormente cursé el Grado Medio de Sistemas Microinformáticos y Redes (SMR).
                Me apasiona la informática y estoy en mi primer día de prácticas,
                con muchas ganas de seguir aprendiendo y creciendo como desarrollador.
            </p>
        </section>
    );
}

export default SobreMi;
