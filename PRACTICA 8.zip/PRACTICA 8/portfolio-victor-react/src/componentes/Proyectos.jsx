function Proyectos({ proyectos }) {
    return (
        <section id="proyectos">
            <h2>Proyectos</h2>
            <div className="proyectos">
                {proyectos.map(function (proyecto) {
                    return (
                        <article className="proyecto" key={proyecto.titulo}>
                            <h3>{proyecto.titulo}</h3>
                            <p>{proyecto.descripcion}</p>
                        </article>
                    );
                })}
            </div>
        </section>
    );
}

export default Proyectos;
