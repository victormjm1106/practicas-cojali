function Estudios({ estudios }) {
    return (
        <section id="estudios">
            <h2>Estudios</h2>

            {estudios.map(function (estudio) {
                return (
                    <article className="tarjeta" key={estudio.titulo}>
                        <h3>{estudio.titulo}</h3>
                        <p><strong>Centro:</strong> {estudio.centro}</p>
                        <p><strong>Período:</strong> {estudio.periodo}</p>
                    </article>
                );
            })}
        </section>
    );
}

export default Estudios;
