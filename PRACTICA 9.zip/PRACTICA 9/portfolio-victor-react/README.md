# Portfolio Víctor React Hooks

Práctica de portfolio personal migrado a React usando Hooks.

## Tecnologías usadas

- React
- Vite
- JavaScript
- CSS
- useState
- useEffect
- LocalStorage
- API de GitHub

## Cómo ejecutar

```bash
npm install
npm run dev
```
