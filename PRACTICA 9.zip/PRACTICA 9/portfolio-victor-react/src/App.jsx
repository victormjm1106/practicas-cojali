import { useEffect, useState } from 'react';
import Cabecera from './componentes/Cabecera.jsx';
import Menu from './componentes/Menu.jsx';
import SobreMi from './componentes/SobreMi.jsx';
import Estudios from './componentes/Estudios.jsx';
import Experiencia from './componentes/Experiencia.jsx';
import Habilidades from './componentes/Habilidades.jsx';
import Proyectos from './componentes/Proyectos.jsx';
import Github from './componentes/Github.jsx';
import Contacto from './componentes/Contacto.jsx';
import Pie from './componentes/Pie.jsx';

const estudiosIniciales = [
    {
        titulo: 'Grado Superior DAM – Desarrollo de Aplicaciones Multiplataforma',
        centro: 'IES Modesto Navarro, La Solana',
        periodo: 'Septiembre 2025 – actualidad',
        fijo: true
    },
    {
        titulo: 'Grado Medio SMR – Sistemas Microinformáticos y Redes',
        centro: 'IES Modesto Navarro, La Solana',
        periodo: 'Septiembre 2023 – Junio 2025',
        fijo: true
    }
];

function App() {
    const [oscuro, setOscuro] = useState(localStorage.getItem('tema') === 'oscuro');
    const [estudios, setEstudios] = useState(function () {
        return JSON.parse(localStorage.getItem('estudios-react')) || estudiosIniciales;
    });

    useEffect(function () {
        localStorage.setItem('estudios-react', JSON.stringify(estudios));
    }, [estudios]);

    function cambiarTema() {
        if (oscuro) {
            localStorage.setItem('tema', 'claro');
            setOscuro(false);
        } else {
            localStorage.setItem('tema', 'oscuro');
            setOscuro(true);
        }
    }

    function añadirEstudio(nuevoEstudio) {
        setEstudios([...estudios, nuevoEstudio]);
    }

    function borrarEstudio(posicion) {
        const nuevaLista = estudios.filter(function (estudio, index) {
            return index !== posicion;
        });
        setEstudios(nuevaLista);
    }

    return (
        <div className={oscuro ? 'pagina oscuro' : 'pagina'}>
            <Cabecera oscuro={oscuro} cambiarTema={cambiarTema} />
            <Menu />
            <main className="contenido">
                <SobreMi />
                <hr />
                <Estudios estudios={estudios} añadirEstudio={añadirEstudio} borrarEstudio={borrarEstudio} />
                <hr />
                <Experiencia />
                <hr />
                <Habilidades />
                <hr />
                <Proyectos />
                <hr />
                <Github />
                <hr />
                <Contacto />
            </main>
            <Pie />
        </div>
    );
}

export default App;
