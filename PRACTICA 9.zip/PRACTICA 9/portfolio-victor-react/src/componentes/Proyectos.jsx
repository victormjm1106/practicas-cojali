function Proyectos() {
    const proyectos = [
        {
            titulo: 'Portfolio personal',
            descripcion: 'Página web personal creada con HTML y CSS durante las prácticas de FP Dual.'
        },
        {
            titulo: 'App de gestión de tareas',
            descripcion: 'Aplicación de escritorio en Java para organizar tareas del día a día.'
        },
        {
            titulo: 'Base de datos de una biblioteca',
            descripcion: 'Diseño y creación de una base de datos relacional para gestionar libros y préstamos.'
        }
    ];

    return (
        <section id="proyectos">
            <h2>Proyectos</h2>
            <div className="proyectos">
                {proyectos.map(function (proyecto) {
                    return (
                        <article className="proyecto" key={proyecto.titulo}>
                            <h3>{proyecto.titulo}</h3>
                            <p>{proyecto.descripcion}</p>
                        </article>
                    );
                })}
            </div>
        </section>
    );
}

export default Proyectos;
