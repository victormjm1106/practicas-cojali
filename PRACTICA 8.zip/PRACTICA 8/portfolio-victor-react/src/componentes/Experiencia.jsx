function Experiencia() {
    return (
        <section id="experiencia">
            <h2>Experiencia laboral</h2>
            <article className="tarjeta">
                <h3>Informático – Prácticas (FP Dual)</h3>
                <p><strong>Empresa:</strong> Ayuntamiento de La Solana</p>
                <p><strong>Lugar:</strong> La Solana, España</p>
                <p>
                    Realización de prácticas de FP Dual en el departamento de informática
                    del Ayuntamiento de La Solana. Aprendizaje en entorno real de trabajo.
                </p>
            </article>
        </section>
    );
}

export default Experiencia;
