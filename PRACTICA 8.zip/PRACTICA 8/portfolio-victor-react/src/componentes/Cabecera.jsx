function Cabecera({ oscuro, cambiarTema }) {
    return (
        <header className="cabecera">
            <div>
                <h1>Víctor Miguel Jiménez Moreno</h1>
                <p>Estudiante de 1º DAM | 18 años | La Solana, España</p>
                <p>
                    Estudiante de Desarrollo de Aplicaciones Multiplataforma con formación previa
                    en Sistemas Microinformáticos y Redes. Interesado en aprender, mejorar mis
                    conocimientos y adquirir experiencia profesional.
                </p>
            </div>
            <button id="btnTema" onClick={cambiarTema}>{oscuro ? '☀️' : '🌙'}</button>
        </header>
    );
}

export default Cabecera;
