# Portfolio Víctor React

Práctica de portfolio personal migrado a React.

## Tecnologías usadas

- React
- Vite
- JavaScript
- CSS

## Cómo ejecutar

```bash
npm install
npm run dev
```
