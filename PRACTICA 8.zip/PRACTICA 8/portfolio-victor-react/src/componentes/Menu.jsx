function Menu() {
    const enlaces = [
        { texto: 'Sobre mí', ruta: '#sobre-mi' },
        { texto: 'Estudios', ruta: '#estudios' },
        { texto: 'Experiencia', ruta: '#experiencia' },
        { texto: 'Habilidades', ruta: '#habilidades' },
        { texto: 'Proyectos', ruta: '#proyectos' },
        { texto: 'Contacto', ruta: '#contacto' }
    ];

    return (
        <nav className="nav">
            <ul>
                {enlaces.map(function (enlace) {
                    return (
                        <li key={enlace.ruta}>
                            <a href={enlace.ruta}>{enlace.texto}</a>
                        </li>
                    );
                })}
            </ul>
        </nav>
    );
}

export default Menu;
