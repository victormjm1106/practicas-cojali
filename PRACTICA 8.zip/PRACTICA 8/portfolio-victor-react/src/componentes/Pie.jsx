function Pie() {
    return (
        <footer className="pie">
            <p>&copy; 2026 Víctor Miguel Jiménez Moreno</p>
            <div className="redes">
                <a href="https://github.com/victormjm1106" target="_blank"><i className="fa-brands fa-github"></i></a>
                <a href="https://linkedin.com/" target="_blank"><i className="fa-brands fa-linkedin"></i></a>
                <a href="https://twitter.com/" target="_blank"><i className="fa-brands fa-x-twitter"></i></a>
            </div>
        </footer>
    );
}

export default Pie;
