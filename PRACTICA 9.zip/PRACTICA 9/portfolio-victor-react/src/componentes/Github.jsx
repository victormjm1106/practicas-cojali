import { useEffect, useState } from 'react';

function Github() {
    const usuario = 'victormjm1106';
    const [perfil, setPerfil] = useState(null);
    const [repos, setRepos] = useState([]);
    const [error, setError] = useState(false);

    useEffect(function () {
        async function cargarGithub() {
            try {
                const respuesta = await fetch('https://api.github.com/users/' + usuario);
                const datosPerfil = await respuesta.json();
                setPerfil(datosPerfil);

                const respuestaRepos = await fetch('https://api.github.com/users/' + usuario + '/repos');
                const datosRepos = await respuestaRepos.json();
                setRepos(datosRepos);
            } catch (e) {
                setError(true);
            }
        }

        cargarGithub();
    }, []);

    return (
        <section id="github">
            <h2>GitHub</h2>

            <article className="tarjeta">
                {error && <p>No se han podido cargar los datos de GitHub.</p>}
                {!perfil && !error && <p>Cargando datos de GitHub...</p>}
                {perfil && (
                    <>
                        <img className="foto" src={perfil.avatar_url} alt="Foto de GitHub" />
                        <h3>{perfil.login}</h3>
                        <p><strong>Repositorios públicos:</strong> {perfil.public_repos}</p>
                        <p><strong>Seguidores:</strong> {perfil.followers}</p>
                        <p><a href={perfil.html_url} target="_blank">Ver perfil de GitHub</a></p>
                    </>
                )}
            </article>

            <h3>Repositorios</h3>
            <div className="proyectos">
                {repos.map(function (repo) {
                    return (
                        <article className="proyecto" key={repo.id}>
                            <h3>{repo.name}</h3>
                            <p>{repo.description || 'Sin descripción'}</p>
                            <p><strong>Lenguaje:</strong> {repo.language || 'No indicado'}</p>
                            <p><a href={repo.html_url} target="_blank">Abrir repositorio</a></p>
                        </article>
                    );
                })}
            </div>
        </section>
    );
}

export default Github;
