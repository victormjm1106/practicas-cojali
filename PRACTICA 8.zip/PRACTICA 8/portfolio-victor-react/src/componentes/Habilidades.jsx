function Habilidades({ habilidades }) {
    return (
        <section id="habilidades">
            <h2>Habilidades laborales</h2>
            <ul>
                {habilidades.map(function (habilidad) {
                    return <li key={habilidad}>{habilidad}</li>;
                })}
            </ul>
        </section>
    );
}

export default Habilidades;
