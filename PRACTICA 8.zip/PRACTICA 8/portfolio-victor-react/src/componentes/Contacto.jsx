function Contacto() {
    return (
        <section id="contacto">
            <h2>Contacto</h2>
            <address className="contacto">
                <p><strong>Teléfono:</strong> +34 625 19 99 23</p>
                <p><strong>Email:</strong> <a href="mailto:victormjm1106@gmail.com">victormjm1106@gmail.com</a></p>
                <p><strong>Ubicación:</strong> La Solana, 13240, España</p>
            </address>
            <br />
            <h3>¿Tienes alguna pregunta o sugerencia?</h3>
            <form className="formulario" action="#" method="get">
                <label htmlFor="nombre">Nombre</label>
                <input type="text" id="nombre" name="nombre" placeholder="Tu nombre" required />

                <label htmlFor="email">Email</label>
                <input type="email" id="email" name="email" placeholder="tu@email.com" required />

                <label htmlFor="mensaje">Mensaje</label>
                <textarea id="mensaje" name="mensaje" placeholder="Escribe tu mensaje aquí..." required></textarea>

                <button type="submit">Enviar</button>
            </form>
        </section>
    );
}

export default Contacto;
